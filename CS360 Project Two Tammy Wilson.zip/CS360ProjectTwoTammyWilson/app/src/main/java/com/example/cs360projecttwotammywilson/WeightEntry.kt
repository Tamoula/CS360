package com.example.cs360projecttwotammywilson

data class WeightEntry(
    val id: Int,
    val date: String,
    val weight: Double
)


