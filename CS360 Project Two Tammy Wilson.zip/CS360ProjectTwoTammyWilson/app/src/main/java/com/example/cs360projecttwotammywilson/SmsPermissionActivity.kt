package com.example.cs360projecttwotammywilson

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class SmsPermissionActivity : AppCompatActivity() {

    private lateinit var btnAllow: Button
    private lateinit var btnDeny: Button

    companion object {
        private const val SMS_PERMISSION_REQUEST = 1001
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_sms_permission)

        btnAllow = findViewById(R.id.buttonAllowSms)
        btnDeny = findViewById(R.id.buttonDenySms)

        btnAllow.setOnClickListener { requestSmsPermission() }
        btnDeny.setOnClickListener { saveSmsEnabled(false) }
    }

    private fun requestSmsPermission() {
        if (ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.SEND_SMS
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(Manifest.permission.SEND_SMS),
                SMS_PERMISSION_REQUEST
            )
        } else {
            saveSmsEnabled(true)
            Toast.makeText(this, "SMS already allowed", Toast.LENGTH_SHORT).show()
        }
    }

    private fun saveSmsEnabled(enabled: Boolean) {
        val prefs = getSharedPreferences("user_prefs", MODE_PRIVATE)
        prefs.edit().putBoolean("sms_enabled", enabled).apply()
        val msg = if (enabled) "SMS alerts enabled" else "SMS alerts disabled"
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
        finish()
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == SMS_PERMISSION_REQUEST) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                saveSmsEnabled(true)
            } else {
                saveSmsEnabled(false)
            }
        }
    }
}