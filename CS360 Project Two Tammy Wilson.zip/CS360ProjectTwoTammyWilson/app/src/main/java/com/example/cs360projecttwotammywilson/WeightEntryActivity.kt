package com.example.cs360projecttwotammywilson

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class WeightEntryActivity : AppCompatActivity() {

    private lateinit var dbHelper: DatabaseHelper
    private lateinit var etWeight: EditText
    private lateinit var btnSave: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_weight_entry)

        dbHelper = DatabaseHelper(this)

        etWeight = findViewById(R.id.editTextWeight)
        btnSave = findViewById(R.id.buttonSaveWeight)

        btnSave.setOnClickListener { saveWeight() }
    }

    private fun saveWeight() {
        val weightText = etWeight.text.toString().trim()

        if (weightText.isEmpty()) {
            Toast.makeText(this, "Enter a weight", Toast.LENGTH_SHORT).show()
            return
        }

        val weight = weightText.toDouble()
        val date = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())

        val prefs = getSharedPreferences("user_prefs", MODE_PRIVATE)
        val userId = prefs.getInt("user_id", -1)

        if (userId == -1) {
            Toast.makeText(this, "User not found", Toast.LENGTH_SHORT).show()
            return
        }

        val success = dbHelper.insertDailyWeight(userId, date, weight)

        if (success) {
            Toast.makeText(this, "Weight saved", Toast.LENGTH_SHORT).show()
            checkGoalAndNotify(this, userId, weight)
            finish()
        } else {
            Toast.makeText(this, "Error saving weight", Toast.LENGTH_SHORT).show()
        }
    }
}
