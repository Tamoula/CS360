package com.example.cs360projecttwotammywilson

import android.database.Cursor
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class HistoryActivity : AppCompatActivity() {

    private lateinit var dbHelper: DatabaseHelper
    private lateinit var recyclerView: RecyclerView
    private lateinit var adapter: WeightAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_history)

        dbHelper = DatabaseHelper(this)

        recyclerView = findViewById(R.id.recyclerViewHistory)
        recyclerView.layoutManager = LinearLayoutManager(this)

        loadHistory()
    }

    private fun loadHistory() {
        val prefs = getSharedPreferences("user_prefs", MODE_PRIVATE)
        val userId = prefs.getInt("user_id", -1)

        val cursor: Cursor = dbHelper.getWeightsForUser(userId)
        val list = mutableListOf<WeightEntry>()

        if (cursor.moveToFirst()) {
            do {
                val id = cursor.getInt(cursor.getColumnIndexOrThrow("id"))
                val date = cursor.getString(cursor.getColumnIndexOrThrow("date"))
                val weight = cursor.getDouble(cursor.getColumnIndexOrThrow("weight"))

                list.add(WeightEntry(id, date, weight))
            } while (cursor.moveToNext())
        }
        cursor.close()

        adapter = WeightAdapter(list) { id ->
            dbHelper.deleteDailyWeight(id)
        }

        recyclerView.adapter = adapter
    }
}
