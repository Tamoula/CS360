package com.example.cs360projecttwotammywilson

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class DatabaseHelper(context: Context) :
    SQLiteOpenHelper(context, DATABASE_NAME, null, DATABASE_VERSION) {

    companion object {
        private const val DATABASE_NAME = "weight_tracker.db"
        private const val DATABASE_VERSION = 1

        // Tables
        private const val TABLE_USERS = "users"
        private const val TABLE_DAILY_WEIGHT = "daily_weight"
        private const val TABLE_GOAL_WEIGHT = "goal_weight"

        // Users columns
        private const val COL_USER_ID = "id"
        private const val COL_USERNAME = "username"
        private const val COL_PASSWORD = "password"

        // Daily weight columns
        private const val COL_WEIGHT_ID = "id"
        private const val COL_WEIGHT_USER_ID = "user_id"
        private const val COL_WEIGHT_DATE = "date"
        private const val COL_WEIGHT_VALUE = "weight"

        // Goal weight columns
        private const val COL_GOAL_ID = "id"
        private const val COL_GOAL_USER_ID = "user_id"
        private const val COL_GOAL_VALUE = "goal_weight"
    }

    override fun onCreate(db: SQLiteDatabase) {
        val createUsersTable = """
            CREATE TABLE $TABLE_USERS (
                $COL_USER_ID INTEGER PRIMARY KEY AUTOINCREMENT,
                $COL_USERNAME TEXT UNIQUE,
                $COL_PASSWORD TEXT
            )
        """.trimIndent()

        val createDailyWeightTable = """
            CREATE TABLE $TABLE_DAILY_WEIGHT (
                $COL_WEIGHT_ID INTEGER PRIMARY KEY AUTOINCREMENT,
                $COL_WEIGHT_USER_ID INTEGER,
                $COL_WEIGHT_DATE TEXT,
                $COL_WEIGHT_VALUE REAL
            )
        """.trimIndent()

        val createGoalWeightTable = """
            CREATE TABLE $TABLE_GOAL_WEIGHT (
                $COL_GOAL_ID INTEGER PRIMARY KEY AUTOINCREMENT,
                $COL_GOAL_USER_ID INTEGER,
                $COL_GOAL_VALUE REAL
            )
        """.trimIndent()

        db.execSQL(createUsersTable)
        db.execSQL(createDailyWeightTable)
        db.execSQL(createGoalWeightTable)
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        db.execSQL("DROP TABLE IF EXISTS $TABLE_USERS")
        db.execSQL("DROP TABLE IF EXISTS $TABLE_DAILY_WEIGHT")
        db.execSQL("DROP TABLE IF EXISTS $TABLE_GOAL_WEIGHT")
        onCreate(db)
    }

    // ---------- USERS ----------

    fun insertUser(username: String, password: String): Boolean {
        val db = writableDatabase
        val values = ContentValues().apply {
            put(COL_USERNAME, username)
            put(COL_PASSWORD, password)
        }
        val result = db.insert(TABLE_USERS, null, values)
        return result != -1L
    }

    fun checkUserCredentials(username: String, password: String): Boolean {
        val db = readableDatabase
        val cursor = db.query(
            TABLE_USERS,
            arrayOf(COL_USER_ID),
            "$COL_USERNAME = ? AND $COL_PASSWORD = ?",
            arrayOf(username, password),
            null, null, null
        )
        val isValid = cursor.count > 0
        cursor.close()
        return isValid
    }

    fun getUserId(username: String): Int? {
        val db = readableDatabase
        val cursor = db.query(
            TABLE_USERS,
            arrayOf(COL_USER_ID),
            "$COL_USERNAME = ?",
            arrayOf(username),
            null, null, null
        )
        var id: Int? = null
        if (cursor.moveToFirst()) {
            id = cursor.getInt(cursor.getColumnIndexOrThrow(COL_USER_ID))
        }
        cursor.close()
        return id
    }

    // ---------- DAILY WEIGHT ----------

    fun insertDailyWeight(userId: Int, date: String, weight: Double): Boolean {
        val db = writableDatabase
        val values = ContentValues().apply {
            put(COL_WEIGHT_USER_ID, userId)
            put(COL_WEIGHT_DATE, date)
            put(COL_WEIGHT_VALUE, weight)
        }
        val result = db.insert(TABLE_DAILY_WEIGHT, null, values)
        return result != -1L
    }

    fun getWeightsForUser(userId: Int): Cursor {
        val db = readableDatabase
        return db.query(
            TABLE_DAILY_WEIGHT,
            null,
            "$COL_WEIGHT_USER_ID = ?",
            arrayOf(userId.toString()),
            null, null,
            "$COL_WEIGHT_DATE ASC"
        )
    }

    fun updateDailyWeight(id: Int, newWeight: Double, newDate: String): Boolean {
        val db = writableDatabase
        val values = ContentValues().apply {
            put(COL_WEIGHT_VALUE, newWeight)
            put(COL_WEIGHT_DATE, newDate)
        }
        val result = db.update(
            TABLE_DAILY_WEIGHT,
            values,
            "$COL_WEIGHT_ID = ?",
            arrayOf(id.toString())
        )
        return result > 0
    }

    fun deleteDailyWeight(id: Int): Boolean {
        val db = writableDatabase
        val result = db.delete(
            TABLE_DAILY_WEIGHT,
            "$COL_WEIGHT_ID = ?",
            arrayOf(id.toString())
        )
        return result > 0
    }

    // ---------- GOAL WEIGHT ----------

    fun setGoalWeight(userId: Int, goalWeight: Double): Boolean {
        val db = writableDatabase

        // Check if goal already exists
        val cursor = db.query(
            TABLE_GOAL_WEIGHT,
            arrayOf(COL_GOAL_ID),
            "$COL_GOAL_USER_ID = ?",
            arrayOf(userId.toString()),
            null, null, null
        )

        val values = ContentValues().apply {
            put(COL_GOAL_USER_ID, userId)
            put(COL_GOAL_VALUE, goalWeight)
        }

        val result = if (cursor.moveToFirst()) {
            val goalId = cursor.getInt(cursor.getColumnIndexOrThrow(COL_GOAL_ID))
            db.update(
                TABLE_GOAL_WEIGHT,
                values,
                "$COL_GOAL_ID = ?",
                arrayOf(goalId.toString())
            )
        } else {
            db.insert(TABLE_GOAL_WEIGHT, null, values)
        }

        cursor.close()
        return result != -1L
    }

    fun getGoalWeight(userId: Int): Double? {
        val db = readableDatabase
        val cursor = db.query(
            TABLE_GOAL_WEIGHT,
            arrayOf(COL_GOAL_VALUE),
            "$COL_GOAL_USER_ID = ?",
            arrayOf(userId.toString()),
            null, null, null
        )
        var goal: Double? = null
        if (cursor.moveToFirst()) {
            goal = cursor.getDouble(cursor.getColumnIndexOrThrow(COL_GOAL_VALUE))
        }
        cursor.close()
        return goal
    }
}

