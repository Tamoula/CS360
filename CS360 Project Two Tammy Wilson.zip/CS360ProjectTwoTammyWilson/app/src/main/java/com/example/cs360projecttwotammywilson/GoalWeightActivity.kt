package com.example.cs360projecttwotammywilson

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity

class GoalWeightActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_goal_weight)
    }
}
