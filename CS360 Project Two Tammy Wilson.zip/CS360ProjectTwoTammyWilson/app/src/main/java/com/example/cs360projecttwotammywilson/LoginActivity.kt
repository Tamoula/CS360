package com.example.cs360projecttwotammywilson

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class LoginActivity : AppCompatActivity() {

    private lateinit var dbHelper: DatabaseHelper
    private lateinit var etUsername: EditText
    private lateinit var etPassword: EditText
    private lateinit var btnLogin: Button
    private lateinit var btnCreateAccount: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        dbHelper = DatabaseHelper(this)

        etUsername = findViewById(R.id.editTextUsername)
        etPassword = findViewById(R.id.editTextPassword)
        btnLogin = findViewById(R.id.buttonLogin)
        btnCreateAccount = findViewById(R.id.buttonCreateAccount)

        btnLogin.setOnClickListener { handleLogin() }
        btnCreateAccount.setOnClickListener { handleCreateAccount() }
    }

    private fun handleLogin() {
        val username = etUsername.text.toString().trim()
        val password = etPassword.text.toString().trim()

        if (username.isEmpty() || password.isEmpty()) {
            Toast.makeText(this, "Please enter username and password", Toast.LENGTH_SHORT).show()
            return
        }

        val isValid = dbHelper.checkUserCredentials(username, password)
        if (isValid) {
            val userId = dbHelper.getUserId(username)
            if (userId != null) {
                val prefs = getSharedPreferences("user_prefs", MODE_PRIVATE)
                prefs.edit().putInt("user_id", userId).apply()

                startActivity(Intent(this, DashboardActivity::class.java))
                finish()
            } else {
                Toast.makeText(this, "Error retrieving user ID", Toast.LENGTH_SHORT).show()
            }
        } else {
            Toast.makeText(this, "Invalid credentials", Toast.LENGTH_SHORT).show()
        }
    }

    private fun handleCreateAccount() {
        val username = etUsername.text.toString().trim()
        val password = etPassword.text.toString().trim()

        if (username.isEmpty() || password.isEmpty()) {
            Toast.makeText(this, "Please enter username and password", Toast.LENGTH_SHORT).show()
            return
        }

        val success = dbHelper.insertUser(username, password)
        if (success) {
            Toast.makeText(this, "Account created. You can now log in.", Toast.LENGTH_SHORT).show()
        } else {
            Toast.makeText(this, "Username may already exist. Try another.", Toast.LENGTH_SHORT).show()
        }
    }
}
