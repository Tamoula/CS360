package com.example.cs360projecttwotammywilson

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Launch LoginActivity immediately
        val intent = Intent(this, LoginActivity::class.java)
        startActivity(intent)

        // Close MainActivity so user cannot return to it
        finish()
    }
}


