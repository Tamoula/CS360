package com.example.cs360projecttwotammywilson

import android.Manifest
import android.content.pm.PackageManager
import android.telephony.SmsManager
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat

fun checkGoalAndNotify(activity: AppCompatActivity, userId: Int, currentWeight: Double) {
    val dbHelper = DatabaseHelper(activity)
    val goal = dbHelper.getGoalWeight(userId)

    if (goal == null) {
        return // No goal set
    }

    if (currentWeight <= goal) {
        val prefs = activity.getSharedPreferences("user_prefs", AppCompatActivity.MODE_PRIVATE)
        val smsEnabled = prefs.getBoolean("sms_enabled", false)

        if (smsEnabled &&
            ContextCompat.checkSelfPermission(
                activity,
                Manifest.permission.SEND_SMS
            ) == PackageManager.PERMISSION_GRANTED
        ) {
            val phoneNumber = "5551234567"
            val message = "Congratulations! You reached your goal weight of $goal."

            try {
                val smsManager = SmsManager.getDefault()
                smsManager.sendTextMessage(phoneNumber, null, message, null, null)
                Toast.makeText(activity, "Goal reached! SMS sent.", Toast.LENGTH_SHORT).show()
            } catch (e: Exception) {
                Toast.makeText(activity, "Failed to send SMS.", Toast.LENGTH_SHORT).show()
            }
        } else {
            Toast.makeText(activity, "Goal reached!", Toast.LENGTH_SHORT).show()
        }
    }
}


