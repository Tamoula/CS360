package com.example.cs360projecttwotammywilson

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity

class DashboardActivity : AppCompatActivity() {

    private lateinit var btnAddWeight: Button
    private lateinit var btnSetGoal: Button
    private lateinit var btnViewHistory: Button
    private lateinit var btnSmsSettings: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_dashboard)

        // Connect UI buttons to Kotlin variables
        btnAddWeight = findViewById(R.id.buttonAddWeight)
        btnSetGoal = findViewById(R.id.buttonSetGoal)
        btnViewHistory = findViewById(R.id.buttonViewHistory)
        btnSmsSettings = findViewById(R.id.buttonSmsSettings)

        // Navigate to Weight Entry screen
        btnAddWeight.setOnClickListener {
            val intent = Intent(this, WeightEntryActivity::class.java)
            startActivity(intent)
        }

        // Navigate to Goal Weight screen
        btnSetGoal.setOnClickListener {
            val intent = Intent(this, GoalWeightActivity::class.java)
            startActivity(intent)
        }

        // Navigate to History (RecyclerView grid)
        btnViewHistory.setOnClickListener {
            val intent = Intent(this, HistoryActivity::class.java)
            startActivity(intent)
        }

        // Navigate to SMS Permission screen
        btnSmsSettings.setOnClickListener {
            val intent = Intent(this, SmsPermissionActivity::class.java)
            startActivity(intent)
        }
    }
}
